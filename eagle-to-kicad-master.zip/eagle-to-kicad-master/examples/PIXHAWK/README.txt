NOTE: ***** USE AT YOUR OWN RISK *****

This contains the eagle file's from PX4 Autopilot Project from git-hub, at https://github.com/PX4 which have been
convert to KiCad. Via's have been converted to Pad, and the modified Eagle files are in

  kicad_files/modified_eagle_files/

The original Eagle files are in

  eagle_original_files/


Also note the Eagle files have been converted to version 6.xx of eagle.
Note:  No Adjustment of power plan's had been made, you will need to adjust them to get correct connection's
       and spacing etc. And as away triple check you results.


sources at:   https://github.com/PX4

















